<!doctype html>
<html>
<head>
<title>my resume</title>
<link rel="stylesheet" href="library/css/form.css">   
</head>
<body style="background-color:#A1C935">
<b><u><center><h3>Admin</h3></u></b></center>
<div align="center"><img src="library/images/admin.png" height="100" width="100"></div>
<div><ul>
<li><font size="4"><a href="stdapproval.php" target="right">Student Approval</a></font></li><br>
<li><font size="4"><a href="addbook.php" target="right">Add books</a></font></li><br>
<li><font size="4"><a href="return book.php" target="right">Return books</a></font></li><br>
<li><font size="4"><a href="issuebook.php" target="right">Issue Book</a></font></li><br>
<li><font size="4"><a href="transactions.php" target="right">Issue List</a></font></li><br>
<li><font size="4"><a href="readbook.php" target="right">Search book</a></font></li><br>
<li><font size="4"><a href="logout.php" target="_top" >Logout</a></font></li><br>
</ul><div>
</body>
</html>


