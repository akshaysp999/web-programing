<?php
 $con = mysqli_connect("localhost","root","","meera_db");
 if(!$con){
    echo "Connection Error";
 }
?>