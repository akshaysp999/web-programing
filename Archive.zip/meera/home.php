<html>
<head>
<title>Library management</title>
</head>
<body style="background-color:#667C26">
<u><center><h1>Library Management</h1></u></center>
<img src="library/images/index.jpeg" width="1000" height="350">
<p>
Library management is a sub-discipline of institutional management that focuses on specific issues faced by libraries and library management professionals. Library management encompasses normal managerial tasks, as well as intellectual freedom and fundraising responsibilities. Issues faced in library management frequently overlap with those faced in managing non-profit organizations.<br>
The basic functions of library management include, but are not limited to: planning and negotiating the acquisition of materials, Interlibrary Loan (ILL) requests, stacks maintenance, overseeing fee collection, event planning, fundraising, and human resources.<br> </p>
</body>
</html>
