<!DOCTYPE html>
<html>
<head>
  <title>library management</title>
 </head>
<frameset cols="75%,25%">
<frame src="home.php" name="left"></frame>
<frame src="login.php" name="right"></frame>
</frameset>
</html>

