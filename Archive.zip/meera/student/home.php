<html>
<head>
<title>Library Management</title>
<link rel="stylesheet" href="form.css"> 
</head>
<body style="background-color:#B2C248">
<u><center><i><h1>Library Management</h1></i></center></u>
<img src="library/images/images.jpeg" width="1000" height="250">
<center><i><h2>Book List</h2></center></i>

<u><h3>--Available Genres--:</h3></u>
<table>
<tr><td><img src="library/images/book1.jpeg" width="150" height="150"><br><center>Fiction</center></td>
<td><img src="library/images/book2.jpeg" width="150" height="150"><br><center>Poetry</center></td>
<td><img src="library/images/book3.jpeg" width="150" height="150"><br><center>Short Story</center></td>
<td><img src="library/images/book4.jpeg" width="150" height="150"><br><center>Novel</center></td>
<td><img src="library/images/book5.jpeg" width="150" height="150"><br><center>Biography</center></td>
</tr>
</table>                   
</body>
</html>
