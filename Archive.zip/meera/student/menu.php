<!doctype html>
<html>
<head>
<title>my resume</title>
<link rel="stylesheet" href="library/css/form.css">   
</head>
<body  style="background-color:#9CB071" >
<b><u><center><h3>Welcome Robb stark</h3></u></b></center>
<div align="center"><img src="library/images/admin.png" height="100" width="100"></div>
<div><ul>
<li><font size="4"><a href="readbook.php" target="right">Read book</a></font></li><br>

<li><font size="4"><a href="logout.php" target="_top"> Logout</a></font></li><br>
</ul><div>
</body>
</html>


