<!DOCTYPE html>
<html>
<head>
  <title>library management</title>
 </head>
<frameset cols="25%,75%" >
<frame src="menu.php" name="left">
<frame src="home.php" name="right">
</frameset>
</html>

